import math

# Initialize the Tic-Tac-Toe board
def create_board():
    return [" " for _ in range(9)]

# Display the board
def print_board(board):
    for i in range(3):
        print(f"{board[3 * i]} | {board[3 * i + 1]} | {board[3 * i + 2]}")
        if i < 2:
            print("--+---+--")

# Check if a player has won
def check_winner(board, player):
    win_conditions = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8],  # Rows
        [0, 3, 6], [1, 4, 7], [2, 5, 8],  # Columns
        [0, 4, 8], [2, 4, 6],            # Diagonals
    ]
    return any(all(board[pos] == player for pos in condition) for condition in win_conditions)

# Check if the board is full
def is_draw(board):
    return " " not in board

# Minimax algorithm for AI
def minimax(board, depth, is_maximizing):
    if check_winner(board, "O"):
        return 1  # AI wins
    if check_winner(board, "X"):
        return -1  # Human wins
    if is_draw(board):
        return 0  # Draw

    if is_maximizing:
        max_eval = -math.inf
        for i in range(9):
            if board[i] == " ":
                board[i] = "O"
                eval = minimax(board, depth + 1, False)
                board[i] = " "
                max_eval = max(max_eval, eval)
        return max_eval
    else:
        min_eval = math.inf
        for i in range(9):
            if board[i] == " ":
                board[i] = "X"
                eval = minimax(board, depth + 1, True)
                board[i] = " "
                min_eval = min(min_eval, eval)
        return min_eval

# Find the best move for the AI
def best_move(board):
    best_val = -math.inf
    move = -1
    for i in range(9):
        if board[i] == " ":
            board[i] = "O"
            move_val = minimax(board, 0, False)
            board[i] = " "
            if move_val > best_val:
                best_val = move_val
                move = i
    return move

# Main game loop
def play_game():
    board = create_board()
    human = "X"
    ai = "O"
    current_player = human

    print("Welcome to Tic-Tac-Toe!")
    print_board(board)

    while True:
        if current_player == human:
            move = int(input("Enter your move (0-8): "))
            if board[move] == " ":
                board[move] = human
                if check_winner(board, human):
                    print_board(board)
                    print("You win!")
                    break
                elif is_draw(board):
                    print_board(board)
                    print("It's a draw!")
                    break
                current_player = ai
            else:
                print("Invalid move. Try again.")
        else:
            print("AI is making its move...")
            move = best_move(board)
            board[move] = ai
            print_board(board)
            if check_winner(board, ai):
                print("AI wins!")
                break
            elif is_draw(board):
                print("It's a draw!")
                break
            current_player = human

if __name__ == "__main__":
    play_game()

'''
Home Work:
- Implement alpha-beta pruning in minimax algorithm to improve performance.
- Implement Q-learning algorithm to train the AI to play Tic-Tac-Toe. 
'''